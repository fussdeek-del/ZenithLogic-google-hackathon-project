
import React, { useState, useRef, useEffect } from 'react';
import { PostMortemResult, TerminalMessage } from '../types';
import { simulateTerminalStep } from '../services/geminiService';

interface Props {
  result: PostMortemResult;
  sourceCode: string;
}

const AnalysisResult: React.FC<Props> = ({ result, sourceCode }) => {
  const [activeTab, setActiveTab] = useState<'audit' | 'enhanced' | 'terminal'>('audit');
  const [terminalHistory, setTerminalHistory] = useState<TerminalMessage[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Use enhanced code for simulation as per requirements
  const executableCode = result.fullEnhancedCode || sourceCode;

  useEffect(() => {
    // Initial simulation output from the result
    if (terminalHistory.length === 0 && result.terminalSimulation) {
      setTerminalHistory([
        { 
          type: 'system', 
          content: `Zenith V-Runtime Initialized [${result.detectedLanguage}]\nCode optimized. Standard input/output stream connected.`, 
          timestamp: Date.now() 
        },
        { 
          type: 'input', 
          content: result.terminalSimulation.actualCommand || `./execute`, 
          timestamp: Date.now() 
        },
        { 
          type: 'output', 
          content: result.terminalSimulation.fullRawOutput || result.terminalSimulation.expectedOutput, 
          timestamp: Date.now() 
        }
      ]);
    }
  }, [result]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalHistory, isProcessing]);

  const handleTerminalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentInput.trim() || isProcessing) return;

    const userInput = currentInput;
    setCurrentInput('');
    setTerminalHistory(prev => [...prev, { type: 'input', content: userInput, timestamp: Date.now() }]);
    setIsProcessing(true);

    try {
      const output = await simulateTerminalStep(executableCode, terminalHistory, userInput);
      
      // Basic check for error patterns in output
      const isError = 
        output.toLowerCase().includes('error') || 
        output.toLowerCase().includes('exception') || 
        output.toLowerCase().includes('traceback');

      setTerminalHistory(prev => [...prev, { 
        type: isError ? 'error' : 'output', 
        content: output, 
        timestamp: Date.now() 
      }]);
    } catch (err) {
      setTerminalHistory(prev => [...prev, { 
        type: 'error', 
        content: "SIMULATION_FAULT: Internal engine failure during execution cycle.", 
        timestamp: Date.now() 
      }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetTerminal = () => {
    setTerminalHistory([
      { 
        type: 'system', 
        content: `Warm reboot initiated. Cleared environment variables. Restarting ${result.detectedLanguage} runtime...`, 
        timestamp: Date.now() 
      },
      { 
        type: 'input', 
        content: result.terminalSimulation.actualCommand || `./execute`, 
        timestamp: Date.now() 
      },
      { 
        type: 'output', 
        content: result.terminalSimulation.fullRawOutput || result.terminalSimulation.expectedOutput, 
        timestamp: Date.now() 
      }
    ]);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* 1. Header & Language Detection */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 glass-panel p-6 rounded-2xl border-l-4 border-l-zinc-500">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] font-bold bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded uppercase tracking-widest">
              Language: {result.detectedLanguage}
            </span>
            <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-500 px-2 py-0.5 rounded uppercase tracking-widest">
              System: Online
            </span>
          </div>
          <h2 className="text-xl font-bold text-zinc-100">Functional Intent</h2>
          <p className="text-zinc-400 text-sm leading-relaxed">{result.purposeSummary}</p>
        </div>
      </div>

      {/* 2. Library & Imports Analysis */}
      <section className="bg-zinc-900/40 p-6 rounded-2xl border border-zinc-800">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4 flex items-center">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
          Module Analysis
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {result.libraryAnalysis.map((lib, idx) => (
            <div key={idx} className="flex items-start space-x-3 p-3 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className={`w-2 h-2 rounded-full mt-1.5 ${lib.isBuiltIn ? 'bg-zinc-600' : 'bg-blue-500'}`} />
              <div>
                <span className="text-xs font-mono font-bold text-zinc-300">{lib.name}</span>
                <p className="text-[11px] text-zinc-500 mt-0.5">{lib.purpose}</p>
              </div>
            </div>
          ))}
          {result.libraryAnalysis.length === 0 && <p className="text-xs text-zinc-600 italic">No external dependencies found.</p>}
        </div>
      </section>

      {/* 4. Tabbed Detail View */}
      <div className="space-y-4">
        <div className="flex bg-zinc-900/60 p-1 rounded-xl border border-zinc-800">
          <button 
            onClick={() => setActiveTab('audit')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'audit' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            Line Audit
          </button>
          <button 
            onClick={() => setActiveTab('enhanced')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'enhanced' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            Improved Logic
          </button>
          <button 
            onClick={() => setActiveTab('terminal')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'terminal' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            Test Runtime
          </button>
        </div>

        <div className="min-h-[400px]">
          {/* Audit View */}
          {activeTab === 'audit' && (
            <div className="space-y-3">
              {result.lineByLineAudit.length === 0 ? (
                <div className="text-center py-12 bg-zinc-900/20 rounded-2xl border border-dashed border-zinc-800">
                   <p className="text-emerald-500 font-bold">Logic Validated: No Fatal Errors Found</p>
                   <p className="text-zinc-500 text-xs mt-1">Review improvements in the next tab.</p>
                </div>
              ) : (
                result.lineByLineAudit.map((issue, idx) => (
                  <div key={idx} className="bg-zinc-900/50 border border-zinc-800 rounded-2xl overflow-hidden">
                    <div className="px-4 py-2 bg-zinc-950/50 border-b border-zinc-800 flex justify-between items-center">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
                        {issue.errorType} @ Line {issue.lineNumber}
                      </span>
                    </div>
                    <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <span className="text-[9px] uppercase font-bold text-zinc-600 block mb-1">Current State</span>
                          <pre className="p-2 bg-red-950/20 border border-red-500/20 text-red-200 text-xs rounded-lg overflow-x-auto font-mono">
                            {issue.originalLine}
                          </pre>
                        </div>
                        <div>
                          <span className="text-[9px] uppercase font-bold text-emerald-600 block mb-1">Proposed Corrective Logic</span>
                          <pre className="p-2 bg-emerald-950/20 border border-emerald-500/20 text-emerald-200 text-xs rounded-lg overflow-x-auto font-mono">
                            {issue.suggestedFix}
                          </pre>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div className="bg-zinc-950/30 p-3 rounded-xl border border-zinc-800/50">
                           <h5 className="text-[10px] font-bold text-zinc-400 uppercase mb-1">Structural Flaw</h5>
                           <p className="text-xs text-zinc-300 leading-relaxed">{issue.technicalExplanation}</p>
                        </div>
                        <div className="bg-zinc-950/30 p-3 rounded-xl border border-zinc-800/50">
                           <h5 className="text-[10px] font-bold text-zinc-400 uppercase mb-1">Logic Translation</h5>
                           <p className="text-xs text-zinc-400 leading-relaxed italic">"{issue.plainLanguageExplanation}"</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Enhanced Code View */}
          {activeTab === 'enhanced' && (
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 relative group">
              <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                 <button 
                  onClick={() => navigator.clipboard.writeText(result.fullEnhancedCode)}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 p-2 rounded-lg text-[10px] font-bold uppercase tracking-widest px-3 py-1.5"
                 >Copy Source</button>
              </div>
              <pre className="font-mono text-xs text-zinc-300 leading-relaxed overflow-x-auto max-h-[600px] custom-scrollbar">
                <code>{result.fullEnhancedCode}</code>
              </pre>
            </div>
          )}

          {/* Terminal View */}
          {activeTab === 'terminal' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-4">
              <div className="flex items-center justify-between px-2">
                 <div className="flex items-center space-x-2">
                    <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Enhanced Runtime Environment</h3>
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                 </div>
                 <button onClick={resetTerminal} className="text-[10px] text-zinc-500 hover:text-white uppercase font-bold flex items-center transition-colors">
                    <svg className="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m0 0H15" /></svg>
                    Reload Session
                 </button>
              </div>
              
              <div className="bg-[#09090b] border-[1px] border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[520px]">
                {/* Terminal Header */}
                <div className="bg-zinc-900/50 px-4 py-3 flex items-center justify-between border-b border-zinc-800">
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 rounded-full bg-zinc-800 border border-zinc-700" />
                      <div className="w-3 h-3 rounded-full bg-zinc-800 border border-zinc-700" />
                      <div className="w-3 h-3 rounded-full bg-zinc-800 border border-zinc-700" />
                    </div>
                    <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-[0.3em]">zenith_sandbox_v2</span>
                </div>
                
                {/* Scrollable Content */}
                <div className="flex-1 p-6 font-mono text-sm overflow-y-auto custom-scrollbar space-y-4 bg-zinc-950/20">
                    {terminalHistory.map((msg, i) => (
                      <div key={i} className="animate-in fade-in duration-300">
                        {msg.type === 'input' && (
                          <div className="flex items-start space-x-3">
                            <span className="text-zinc-600 font-bold">$</span>
                            <span className="text-zinc-100 font-medium tracking-tight">{msg.content}</span>
                          </div>
                        )}
                        {msg.type === 'output' && (
                          <div className="text-zinc-400 whitespace-pre-wrap leading-relaxed py-1 font-light tracking-wide">{msg.content}</div>
                        )}
                        {msg.type === 'error' && (
                          <div className="text-red-400 bg-red-500/5 p-3 rounded-lg border border-red-500/10 whitespace-pre-wrap leading-relaxed font-mono text-xs mt-2">
                             <div className="text-[10px] font-bold text-red-500 uppercase mb-1 opacity-50 tracking-widest">Runtime_Fault_Detected</div>
                             {msg.content}
                          </div>
                        )}
                        {msg.type === 'system' && (
                          <div className="text-zinc-500 text-[10px] border-b border-zinc-900/50 pb-3 mb-2 font-bold tracking-widest uppercase">
                            [SYS_INIT] {msg.content}
                          </div>
                        )}
                      </div>
                    ))}
                    {isProcessing && (
                      <div className="flex items-center space-x-2 text-zinc-500">
                        <span className="text-zinc-700 font-bold">$</span>
                        <span className="w-1.5 h-4 bg-zinc-700 animate-pulse"></span>
                        <span className="text-[9px] text-zinc-700 italic ml-2">Simulating cycles...</span>
                      </div>
                    )}
                    <div ref={terminalEndRef} />
                </div>

                {/* Interactive Input Area */}
                <form onSubmit={handleTerminalSubmit} className="bg-zinc-900/30 border-t border-zinc-800 px-6 py-4 flex items-center space-x-3 focus-within:bg-zinc-900/50 transition-colors">
                   <span className="text-zinc-500 font-bold text-sm">$</span>
                   <input
                    type="text"
                    value={currentInput}
                    onChange={(e) => setCurrentInput(e.target.value)}
                    disabled={isProcessing}
                    placeholder={isProcessing ? "Processing improved logic..." : "Send input to runtime..."}
                    className="flex-1 bg-transparent border-none outline-none text-zinc-100 font-mono text-sm placeholder:text-zinc-700 focus:ring-0"
                    autoFocus
                   />
                   <div className="text-[9px] text-zinc-700 font-bold uppercase tracking-[0.2em] pointer-events-none select-none">
                      Enhanced_IO
                   </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 5. Enhancement Suggestions Section */}
      <section className="bg-zinc-900/20 p-8 rounded-2xl border border-zinc-800">
         <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-6">Optimization Roadmap</h3>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {result.enhancementSuggestions.map((suggestion, idx) => (
              <div key={idx} className="flex items-start space-x-4 p-4 bg-zinc-950/30 rounded-xl border border-zinc-800/50 hover:border-zinc-700 transition-colors">
                 <span className="w-6 h-6 bg-zinc-800 rounded flex items-center justify-center text-[10px] font-bold text-zinc-500 flex-shrink-0 border border-zinc-700/50 shadow-inner">
                    {idx + 1}
                 </span>
                 <p className="text-xs text-zinc-400 leading-relaxed font-medium">{suggestion}</p>
              </div>
            ))}
         </div>
      </section>

      <style>{`
        @keyframes blink { 
          0%, 100% { opacity: 1; } 
          50% { opacity: 0; } 
        }
        .animate-blink { animation: blink 1s step-end infinite; }
      `}</style>
    </div>
  );
};

export default AnalysisResult;
