
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="py-6 px-4 border-b border-zinc-800 bg-zinc-900/30 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-zinc-100 rounded flex items-center justify-center">
            <svg className="w-5 h-5 text-zinc-950" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter text-zinc-100">Zenith<span className="text-zinc-500 font-medium italic ml-1">Logic</span></h1>
            <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-[0.2em]">Elite Autopsy Engine</p>
          </div>
        </div>
        <div className="hidden md:flex items-center space-x-6 text-[10px] font-bold uppercase tracking-widest text-zinc-500">
          <span className="flex items-center border-r border-zinc-800 pr-6"><span className="w-1.5 h-1.5 bg-zinc-400 rounded-full mr-2"></span> Gemini 3 Pro</span>
          <span className="text-zinc-400">v2.1.0-autopsy</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
