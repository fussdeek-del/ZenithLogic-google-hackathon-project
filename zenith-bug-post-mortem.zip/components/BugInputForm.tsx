
import React, { useState, useRef } from 'react';
import { BugReport } from '../types';

interface Props {
  onSubmit: (report: BugReport) => void;
  isLoading: boolean;
}

const BugInputForm: React.FC<Props> = ({ onSubmit, isLoading }) => {
  const [code, setCode] = useState('');
  const [expectedBehavior, setExpectedBehavior] = useState('');
  const [actualOutput, setActualOutput] = useState('');
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCode(content);
    };
    reader.readAsText(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !expectedBehavior || !actualOutput) return;
    onSubmit({ code, expectedBehavior, actualOutput, fileName });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-300 flex justify-between items-center">
          <span>SOURCE CODE / FILE UPLOAD</span>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-xs bg-slate-800 hover:bg-slate-700 text-blue-400 py-1 px-3 rounded-md border border-slate-700 transition-colors flex items-center space-x-1"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            <span>{fileName ? 'Change File' : 'Upload File'}</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>
        
        {fileName && (
          <div className="flex items-center space-x-2 text-xs text-blue-400 bg-blue-500/10 p-2 rounded-lg border border-blue-500/20">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span>Loaded: <span className="font-mono font-bold">{fileName}</span></span>
            <button 
              type="button" 
              onClick={() => { setFileName(''); setCode(''); }}
              className="ml-auto text-slate-500 hover:text-red-400"
            >
              Clear
            </button>
          </div>
        )}

        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Paste code or upload a file..."
          className="w-full h-48 mono bg-slate-900 border border-slate-700 rounded-xl p-4 text-sm text-blue-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-600"
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-300">EXPECTED BEHAVIOR</label>
          <textarea
            value={expectedBehavior}
            onChange={(e) => setExpectedBehavior(e.target.value)}
            placeholder="What should the code do?"
            className="w-full h-32 bg-slate-900 border border-slate-700 rounded-xl p-4 text-sm text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-600"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-300">ACTUAL OUTPUT / ERROR</label>
          <textarea
            value={actualOutput}
            onChange={(e) => setActualOutput(e.target.value)}
            placeholder="What went wrong?"
            className="w-full h-32 bg-slate-900 border border-slate-700 rounded-xl p-4 text-sm text-red-200 focus:ring-2 focus:ring-red-500 outline-none transition-all placeholder:text-slate-600"
            required
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className={`w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center space-x-2 ${
          isLoading 
            ? 'bg-slate-700 text-slate-400 cursor-not-allowed' 
            : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20 active:scale-[0.98]'
        }`}
      >
        {isLoading ? (
          <>
            <svg className="animate-spin h-5 w-5 mr-3 text-white" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span>AUDITING LOGIC...</span>
          </>
        ) : (
          <>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            <span>INITIATE FULL ANALYSIS</span>
          </>
        )}
      </button>
    </form>
  );
};

export default BugInputForm;
