
import { GoogleGenAI, Type } from "@google/genai";
import { BugReport, PostMortemResult, TerminalMessage } from "../types";

const MODEL_NAME = 'gemini-3-pro-preview';

export const analyzeBug = async (report: BugReport): Promise<PostMortemResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Perform a comprehensive AI Code Review and Logic Autopsy.
  
  FILE: ${report.fileName || 'unnamed_source'}
  INPUT CODE:
  \`\`\`
  ${report.code}
  \`\`\`
  
  CONTEXT:
  - Intended Behavior: ${report.expectedBehavior}
  - Reported Error/Output: ${report.actualOutput}
  
  TASKS:
  1. Detect programming language.
  2. Write a "Purpose Summary" for a non-technical person.
  3. Analyze all imports and built-in libraries used.
  4. Provide a "Code Overview" explaining the main logic and loops in plain language.
  5. Audit the code line-by-line. Identify bugs (Syntax, Logic, Runtime, Typos).
  6. If no bugs are found, provide "Enhancement Suggestions" for professional maintainability.
  7. Generate a "Full Enhanced Code" version with better variable names, comments, and formatting.
  8. Simulate a terminal execution based on the code's logic. Include the specific command that would be executed (e.g., 'python script.py') and the full, detailed raw output.
  
  Output MUST follow the provided JSON schema strictly.`;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          detectedLanguage: { type: Type.STRING },
          purposeSummary: { type: Type.STRING },
          libraryAnalysis: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                purpose: { type: Type.STRING },
                isBuiltIn: { type: Type.BOOLEAN }
              },
              required: ["name", "purpose", "isBuiltIn"]
            }
          },
          codeOverview: {
            type: Type.OBJECT,
            properties: {
              overall: { type: Type.STRING },
              keyLogicPoints: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["overall", "keyLogicPoints"]
          },
          assumptionError: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING }
            },
            required: ["title", "description"]
          },
          lineByLineAudit: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                lineNumber: { type: Type.NUMBER },
                originalLine: { type: Type.STRING },
                errorType: { type: Type.STRING },
                technicalExplanation: { type: Type.STRING },
                plainLanguageExplanation: { type: Type.STRING },
                suggestedFix: { type: Type.STRING },
                fixedOutputExample: { type: Type.STRING }
              },
              required: ["lineNumber", "originalLine", "errorType", "technicalExplanation", "plainLanguageExplanation", "suggestedFix"]
            }
          },
          enhancementSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          fullEnhancedCode: { type: Type.STRING },
          terminalSimulation: {
            type: Type.OBJECT,
            properties: {
              sampleInput: { type: Type.STRING },
              expectedOutput: { type: Type.STRING },
              status: { type: Type.STRING },
              actualCommand: { type: Type.STRING },
              fullRawOutput: { type: Type.STRING }
            },
            required: ["sampleInput", "expectedOutput", "status", "actualCommand", "fullRawOutput"]
          }
        },
        required: ["detectedLanguage", "purposeSummary", "libraryAnalysis", "codeOverview", "assumptionError", "lineByLineAudit", "enhancementSuggestions", "fullEnhancedCode", "terminalSimulation"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Analysis failed.");
  return JSON.parse(text.trim()) as PostMortemResult;
};

export const simulateTerminalStep = async (
  code: string, 
  history: TerminalMessage[], 
  newInput: string
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const historyText = history
    .map(m => {
      if (m.type === 'system') return `[SYSTEM]: ${m.content}`;
      if (m.type === 'input') return `[USER INPUT]: ${m.content}`;
      if (m.type === 'output') return `[RUNTIME OUTPUT]: ${m.content}`;
      if (m.type === 'error') return `[RUNTIME ERROR]: ${m.content}`;
      return `${m.content}`;
    })
    .join('\n');

  const prompt = `Act as a high-fidelity virtual runtime environment for the following ENHANCED code:
\`\`\`
${code}
\`\`\`

Current Session Execution Context:
${historyText}

LATEST USER INTERACTION: ${newInput}

Your Task:
1. Process the latest interaction based on the code's logic. 
2. Maintain the internal state (variables, logic flow) from previous interactions in the history.
3. If the code requires further input (e.g. from an 'input()' or 'scanf' equivalent), provide the appropriate prompt.
4. If an exception occurs, provide a realistic traceback or error message matching the language syntax.
5. Return ONLY the next chunk of terminal output. Do not add commentary. 

TERMINAL_OUTPUT:`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.1,
      topP: 0.9,
    }
  });

  return response.text?.trim() || " ";
};
